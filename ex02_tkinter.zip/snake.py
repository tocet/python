import tkinter as tk
import time
import random
import sys
import math
####################################################################################################################
# PARAMETRY GRY
# okno gry
snake_window = tk.Tk()
# rozmiery okna gry
win_x, win_y = 800, 800
game_window_dimensions = [win_x, win_y]
snake_window.geometry(str(win_x) + "x" + str(win_y))
# blokada zmiany rozmiarów okna gry
snake_window.resizable(0, 0)
# tytuł gry
snake_window.title("Snake")
# obsługa zamkniecia okna gry
snake_window.protocol("WM_DELETE_WINDOW", sys.exit)
# okno gry: bd - tło; highlightthickness - obramowanie
snake_canvas = tk.Canvas(snake_window, width=win_x, height=win_y, bd=0, highlightthickness=0)
# www.activestate.com/resources/quick-reads/how-to-use-pack-in-tkinter/
snake_canvas.pack()
# rozmiary segmentu weża
snake_scale = 25
game_dimensions = [win_x // snake_scale, win_y // snake_scale]
# początkowa pozycja głowy weża, lista definująca ogon
snake_coords = [game_dimensions[0] // 2, game_dimensions[1] // 2]
snake_tail = []
# kierunek ruchu weża[x,y]
snake_move_dir = [1, 0]
snake_moved_in_this_frame = False
# parametry gry - ilość wyświetleń/sec
wps = 10
####################################################################################################################
# FUNKCJE GRY
####################################################################################################################
# wypełnianie pola na siatce
def createGridItem(coords, hexcolor):
    snake_canvas.create_rectangle((coords[0]) * snake_scale, (coords[1]) * snake_scale, (coords[0] + 1) * snake_scale,
                                 (coords[1] + 1) * snake_scale, fill=hexcolor, outline="#222222", width=3)

# losowanie pozycji jabłka
def generateAppleCoords():
    # zmienna globalna
    global snake_tail
    # współrzedne jabłka
    apple_coords = [random.randint(0, (game_dimensions[0] - 1)), random.randint(0, (game_dimensions[1] - 1))]
    # czy jabłko nie jest cześcią weża - rekurencja
    for segment in snake_tail:
        if (segment[0] == apple_coords[0] and segment[1] == apple_coords[1]):
            return generateAppleCoords()
    # współrzedne jabłka
    return apple_coords

# gra
def gameloop():
    # deklaracja użycia zmiennych globalnych
    global wps
    global snake_moved_in_this_frame
    global snake_canvas
    global game_dimensions
    global window_dimensions
    global snake_tail
    global snake_coords
    global snake_move_dir
    global apple_coords

    # gra jest wywoływana co 1s/wps (ilość okien na sekunde)
    snake_window.after(1000 // wps, gameloop)
    # czyszczenie okna gry
    snake_canvas.delete("all")
    # ustawienie tła
    snake_canvas.create_rectangle(0, 0, win_x, win_y, fill="#222222", outline="#222222")

    # dodanie głowy
    snake_tail.append([snake_coords[0], snake_coords[1]])
    # przemieszczenie weża
    snake_coords[0] += snake_move_dir[0]
    snake_coords[1] += snake_move_dir[1]
    # przechodzenie przez ściany
    if (snake_coords[0] == game_dimensions[0]):
        snake_coords[0] = 0
    elif (snake_coords[0] == -1):
        snake_coords[0] = game_dimensions[0] - 1
    elif (snake_coords[1] == game_dimensions[1]):
        snake_coords[1] = 0
    elif (snake_coords[1] == -1):
        snake_coords[1] = game_dimensions[1] - 1
    # ruch w danej ramce obrazu przetworzony
    snake_moved_in_this_frame = False

    # kolizaja głowy z ogonem - restart gry
    for segment in snake_tail:
        if (segment[0] == snake_coords[0] and segment[1] == snake_coords[1]):
            snake_coords = [game_dimensions[0] // 2, game_dimensions[1] // 2]
            snake_tail = []
            snake_move_dir = [1, 0]
            apple_coords = generateAppleCoords()
        # wyswietlanie weza
        createGridItem(segment, "#00ff00")

    # wyświetlenie jabłka
    createGridItem(apple_coords, "#ff0000")
    # jeżeli jabłko zjedzone wydłuż ogon
    if (apple_coords[0] == snake_coords[0] and apple_coords[1] == snake_coords[1]):
        apple_coords = generateAppleCoords()
    else:
        snake_tail.pop(0)

# obsługa klawiatury
def key(e):
    # deklaracja użycia zmiennych globalnych
    global snake_move_dir
    global snake_moved_in_this_frame

    # czy zmiana położenia w danej ramce
    if (snake_moved_in_this_frame == False):
        snake_moved_in_this_frame = True

        # przciski ze strzałkami
        if (e.keysym == "Left" and snake_move_dir[0] != 1):
            snake_move_dir  = [-1, 0]
        elif (e.keysym == "Right" and snake_move_dir[0] != -1):
            snake_move_dir  = [1, 0]
        elif (e.keysym == "Up" and snake_move_dir[1] != 1):
            snake_move_dir  = [0, -1]
        elif (e.keysym == "Down" and snake_move_dir[1] != -1):
            snake_move_dir  = [0, 1]
        else:
            snake_moved_in_this_frame = False
####################################################################################################################
# 1 losowanie jabłka
apple_coords = generateAppleCoords()

# funkcja wiążąca ze zdarzeniem z klawiatury
#https://www.geeksforgeeks.org/python-binding-function-in-tkinter/
snake_window.bind("<KeyPress>", key)
# gra
gameloop()
# wyświetlenie okna gry i czekanie na zdarzenie z klawiatury
snake_window.mainloop()
