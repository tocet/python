import tkinter as tk

#window
wnd = tk.Tk()
wnd.title("Tkinter demo")

#run
wnd.mainloop()