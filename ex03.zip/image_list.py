import os

for images in os.listdir():
    if (images.endswith(".png") or images.endswith(".jpg") or images.endswith(".jpeg")):
        # display
        print(images)
        print(type(images))