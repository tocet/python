import cv2
import time
import HandTracking as htc

c_time = 0
p_time = 0

#webcam
cap = cv2.VideoCapture(0)
detector = htc.HandDetector()

while True:
   _, img = cap.read()
   img = detector.findHand(img,True)
   landmarkList = detector.findPostition(img,draw = True)

   if len(landmarkList) != 0:
       print(landmarkList[2])

   c_time = time.time()
   fps = int(1 / (c_time - p_time))
   p_time = c_time
   cv2.putText(img, str(fps), (15, 80), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 0, 255), 2)

   cv2.imshow("Image", img)
   if cv2.waitKey(1) & 0xFF == ord('q'):
       break

cap.release()
cv2.destroyAllWindows()