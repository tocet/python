#lists
temps = [ 0.0, 100.0, -17.78, 27.5, 37.78, 7.39 ]
print(temps)
car_details = [ 'Kia', 'Sportage', 1.6, 3200]
print(car_details)
list_of_lists = [ [ 1, 2, 3], ['a', 'b', 'c' ], [ 'Jeden','Dwa','Trzy' ] ]
print(list_of_lists)
