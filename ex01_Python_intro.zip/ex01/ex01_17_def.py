def search4letters(word:str, letters:str="aeiou") -> set:
    """Wyszukuje litery w słowie wejściowym"""
    return set(letters).intersection(set(word))

help(search4letters)
print(search4letters("atest"))
