def search4vowels(word):
    vowels = set('aeiou')
    found = vowels.intersection(set(word))
    return bool(found)
        
print(search4vowels("Test"))
