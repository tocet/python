numbers = []
print(len(numbers))

numbers.append(10)
print(numbers)

numbers = [1,2,3,4]
print(numbers)

print("Usuniecie ----------------------------")
# usuniecie elementu o okreslonej wartosci
numbers.remove(1)
print(numbers)

# usuniecie elementu o okreslonym indeksie
del_num = numbers.pop(1)
print(numbers)
print(del_num)

print("Rozszerzenie ----------------------------")
# rozszerzenie o liste obiektów
numbers.extend([5,6])
print(numbers)

# rozszerzenie o obiekt (1) wstawiony PRZED indeksem(0)
numbers.insert(0,1)
print(numbers)

numbers.insert(1,2)
print(numbers)

print("Kopiowanie ----------------------------")
# kopiowanie
numbers = list(range(10))
print(numbers)
numbers2 = numbers
numbers3 = numbers.copy()
print(numbers2)
print(numbers3)
numbers.append(100)
print(numbers)
print(numbers2)
print(numbers3)
