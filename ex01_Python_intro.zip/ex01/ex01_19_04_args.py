def vargs_func(*args, **kwargs):
    print("Number of parameters *args:",len(args))
    for arg in args:
        print ("Arg ", arg)

    print("Number of parameters **kwargs:",len(kwargs))
    for key, item in kwargs.items():
        print ("Key ", key, "Value ", item)

vargs_func(1,2,'x',[1,'a',2],a=1,b=2,c=3)
