def search4vowels(word):
    vowels = set('aeiou')
    return vowels.intersection(set(word))

print(search4vowels("atest"))
