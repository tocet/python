def vargs_func(*args):
    print(args)
        
vargs_func('a','b','c')
vargs_func(1,2,3,4,5)
