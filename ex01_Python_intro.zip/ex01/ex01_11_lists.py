#eg p.67

s_letters = "AbCdEfGh"
letters = list(s_letters)
print(s_letters)
print(letters)

print(letters[0])
print(letters[2])
print(letters[-1])
print(letters[-3])

print(letters[3:])
print(letters[:2])
print(letters[::2])
print(letters[1:3])
print(letters[0:7:2])

print(''.join(letters[-3:]))
print(''.join(letters[::-1]))

for ch in letters:
    print('\t',ch)

for ch in letters[0:7:2]:
    print('\t \t',ch)
