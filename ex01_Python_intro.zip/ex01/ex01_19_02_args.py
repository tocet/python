def vargs_func(*args):
    print("Liczba przekazanych parametrów:",len(args))
    for arg in args:
        print ("Wartość:",arg)
        
lista = [1,2,3,4]
vargs_func(1,lista,2,'xyz',3)
