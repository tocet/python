person = {'Name': 'Tom',
          'Phone': '123456789',
          'Occupation': 'engineer',
          'Home planet': 'Earth'}
print(person)
print(person['Home planet'])

person['Age'] = 21
print(person)

#vowels = {'a' : 0, 'e' : 0, 'i' : 0, 'o' : 0, 'u' : 0}
vowels = ['a','e','i','o','u']
found_vowels ={}
word = input("Enter Your word: ")
for letter in word:
    if letter in vowels:
        found_vowels.setdefault(letter,0)
        found_vowels[letter] += 1

#k:v -> klucz:wartość        
for k, v in sorted(found_vowels.items()):
    print(k, 'found', v, 'times')
