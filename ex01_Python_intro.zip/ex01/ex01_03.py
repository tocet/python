import time as t

today = t.strftime("%A")
if today == "Saturday":
    print("Python course")
elif today == "Sunday":
    print("No Python classes")
else:
    print("No classes at all")
