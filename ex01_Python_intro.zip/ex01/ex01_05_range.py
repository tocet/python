print(range(4))

print(list(range(4)))

print(list(range(4,10)))

print(list(range(0,8,2)))

print(list(range(8,0,-2)))
