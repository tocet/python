for i in [1,2,3,4]:
    print(i)
print("----------")

for i in "Python":
    print(i)
print("----------")

for i in range(4):
    print("Python")
print("----------")
