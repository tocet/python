def vargs_func(**kwargs):
    print("Number of parameters:",len(kwargs))
    for key, item in kwargs.items():
        print ("Key ", key, "Vslue ", item)

vargs_func(a=1,b=2,c=3)
