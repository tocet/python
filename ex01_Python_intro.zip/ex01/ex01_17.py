def change(phrase, position):
    if phrase[position].isupper():
        phrase = phrase[0:position] + phrase[position].lower() + phrase[position+1:]
    else:
        phrase = phrase[0:position] + phrase[position].upper() + phrase[position+1:]
    if position == len(phrase)-1: return phrase;
    return change(phrase, position+1)

txt = "Long long time ago. In the galaxy far away..."
print(change(txt, 0))
