lista = [1,3,5,7]
lista = [i+1 for i in lista]
print(lista)

lista = [1,3,4,5,7,8]
lista = [i for i in lista if i % 2 == 0 ]
print(lista)

lista = [1,3,4,5,7,8]
lista = ['Parzysta' if i%2 == 0 else 'Nieparzysta' for i in lista]
print(lista)

lista = [1,3,4,5,7,8]
def func(i):
    if i % 2 == 0: return 'Parzyste'
    else: return 'Nieparzyste'    
lista = [func(i) for i in lista]
print(lista)
