# while
licznik = 0

while licznik < 3:
    print("Inside while")
    licznik = licznik + 1
else:
    print("Inside else")


# do-while
while True:
    liczba = int(input("Wprowadź liczbe dodatnią: "))
    if liczba > 0:
        print("OK")
        break
    print('Liczba ujemna')
    
