#zbiór - nie ma duplikatów
vowels = set('aeiou')
word = input("Enter Your word: ")
sum_sets = vowels.union(set(word))
print(sum_sets)
diff_sets = vowels.difference(set(word))
print(diff_sets)
common_part=vowels.intersection(set(word))
print(common_part)

#krotka(tuple) vs string
t = ('P','y','t','h','o','n')
print(t)
t = ('Python')
print(type(t))
t = ('Python',)
print(t)
print(type(t))
